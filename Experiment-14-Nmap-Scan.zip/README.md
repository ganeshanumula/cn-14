# Experiment 14: How to Run an Nmap Scan

## Aim
Learn to run an Nmap scan using Nmap/Zenmap and interpret scan results.

## Repository contents
- `README.md` — overview and run notes
- `Practical-Documentation.md` — procedure, examples, observation template, and conclusion
- `Original-Practical.docx` — supplied lab handout
- `evidence/` — add genuine screenshots and logs here
- `diagrams/authorized-nmap-workflow.svg` — workflow diagram

## Evidence
Add your own screenshots from the lab run. Do not submit sample output as if it were captured from your machine.

## GitHub upload
Create a public repository, upload these files, add actual evidence, and commit the changes.
